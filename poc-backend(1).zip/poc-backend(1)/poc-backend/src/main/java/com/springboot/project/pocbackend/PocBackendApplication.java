package com.springboot.project.pocbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocBackendApplication.class, args);
	}

}

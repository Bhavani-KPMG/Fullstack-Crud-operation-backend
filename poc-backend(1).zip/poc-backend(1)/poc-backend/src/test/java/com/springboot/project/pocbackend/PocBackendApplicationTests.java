package com.springboot.project.pocbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
